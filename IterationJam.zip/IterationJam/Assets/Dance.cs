﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
public class Dance : MonoBehaviour
{
    public Volume V;
    public LensDistortion LD;

    // Start is called before the first frame update
    void Start()
    {
        LensDistortion tmp;

        if (V.profile.TryGet(out tmp))
        {
            LD = tmp;
        }
    }

    // Update is called once per frame
    void Update()
    {
        LD.xMultiplier.Override(Mathf.PingPong(Time.time * 2, 1));
        LD.yMultiplier.Override(Mathf.PingPong(Time.time * 2, 1));
        //LD.xMultiplier = new ClampedFloatParameter(Mathf.Sin(Time.time * 5), -1, 1);
        //LD.yMultiplier = new ClampedFloatParameter(Mathf.Sin(Time.time * 5), -1, 1);
    }
}
