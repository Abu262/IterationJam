﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Enemy20 : EnemyScr
{
    public GameObject bullet;
    float targetTime = 0.0f;
    float targetTime2 = 0.0f;
    float targetTime3 = 0.0f;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Player != null)
        {


            if (!dead && SP.enabled == true)
            {
                dead = death();
                targetTime += Time.deltaTime;
                targetTime2 += Time.deltaTime;

                targetTime3 += Time.deltaTime;
                transform.Rotate(Vector3.forward * Time.deltaTime * 45);
                if (targetTime > 0.3f)
                {
                    //fire
                    targetTime = 0.0f;
                    for (int i = 0; i < 4; i++)
                    {
                        GameObject bulletInstance = Instantiate(bullet, transform.position, transform.rotation) as GameObject;
                        bulletInstance.GetComponent<EnemyBulletScr>().SW = SW;
                        bulletInstance.GetComponent<EnemyBulletScr>().ES = this;
                        bulletInstance.GetComponent<EnemyBulletScr>().speed = 10;
                        var dir = transform.up;
                        var angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg - (90 * i);
                        bulletInstance.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
                    }


                }
                if (targetTime2 > 0.15f)
                {
                    targetTime2 = -0.15f;
                    for (int i = 0; i < 4; i++)
                    {
                        GameObject bulletInstance = Instantiate(bullet, transform.position, transform.rotation) as GameObject;
                        bulletInstance.GetComponent<EnemyBulletScr>().SW = SW;
                        bulletInstance.GetComponent<EnemyBulletScr>().ES = this;
                        bulletInstance.GetComponent<EnemyBulletScr>().speed = 10;
                        var dir = transform.up;
                        var angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg - (90 * i) + 45;
                        bulletInstance.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
                    }
                }


                if (targetTime3 > 0.4f)
                {
                    //fire
                    targetTime3 = 0.0f;
                    GameObject bulletInstance = Instantiate(bullet, transform.position, Quaternion.Euler(new Vector3(0, 0, 0))) as GameObject;
                    bulletInstance.GetComponent<EnemyBulletScr>().SW = SW;
                    bulletInstance.GetComponent<EnemyBulletScr>().ES = this;
                    bulletInstance.GetComponent<EnemyBulletScr>().speed = 15;
                    var dir = Player.transform.position - transform.position;
                    var angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg - 90;
                    bulletInstance.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

                }

            }
            else
            {
                if (Input.GetKeyDown(KeyCode.Space))
                {

                    SceneManager.LoadScene(0);
                }
                if (Input.GetKeyDown(KeyCode.Backspace))
                {
                    SceneManager.LoadScene(0);
                }
            }
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {

                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
            if (Input.GetKeyDown(KeyCode.Backspace))
            {
                SceneManager.LoadScene(0);
            }
        }


    }

    private void FixedUpdate()
    {
        if (Player != null)
        {
            Vector3 dir = Vector3.Normalize((Player.transform.position - transform.position)) * speed;
            Vector2 dir2D = new Vector2(dir.x, dir.y);
            rb.AddForce(dir2D);
            reverseVel(-dir2D);
        }

    }

    void reverseVel(Vector2 vel)
    {
        if (Mathf.Abs(rb.velocity.magnitude) > speed)
        {
            rb.AddForce(-vel);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            Instantiate(collision.gameObject.GetComponent<TopDownMovement>().PS, collision.transform.position, collision.transform.rotation);
            StartCoroutine(SW.StringPrintCo("CUBE,WINS,CUBE WINS", 0.4f));
            StartCoroutine(SW.tryAgain());
            Destroy(collision.gameObject);
        }
    }
}