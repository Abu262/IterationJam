﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ScreenWriter : MonoBehaviour
{
    public TextMeshProUGUI TMP;
    float timer = 0.4f;
    public string startString;
    EnemyScr ES;
    public GameObject divider;

    public TextMeshProUGUI TMPL;
    public TextMeshProUGUI TMPR;

    // Start is called before the first frame update
    void Start()
    {
        TMP.fontSize = 8;
        StartCoroutine(StringPrintCo(startString, timer));
    }

    // Update is called once per frame
    void Update()
    {
    }


    public IEnumerator StringPrintCo(string phrase, float t)
    {
        string[] someString = phrase.Split(", "[0]);
        foreach (string s in someString)
        {


            TMP.text = s;
            yield return new WaitForSeconds(0.5f);
 
        }
        TMP.text = "";
        divider.SetActive(false);
        yield return null;
    }

    public IEnumerator nextLevel()
    {
        TMPL.text = "SPACEBAR: NEXT LEVEL";
        TMPR.text = "BACKSPACE: QUIT";
        yield return null;
    }

    public IEnumerator tryAgain()
    {
        TMPL.text = "SPACEBAR: RETRY";
        TMPR.text = "BACKSPACE: QUIT";
        yield return null;
    }
}
