﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Enemy12 : EnemyScr
{
    bool lastDead = true;
    SceneHandler SC;
    public GameObject E;
    // Start is called before the first frame update
    void Start()
    {
        SC = FindObjectOfType<SceneHandler>();
        Player = GameObject.FindWithTag("Player");
        SW = FindObjectOfType<ScreenWriter>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Player != null)
        {


            if (!dead)
            {
                dead = death();
                if (dead)
                {
                    
                    Instantiate(PS, transform.position, transform.rotation);
                    if (transform.localScale.x == 16f)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            GameObject newE = Instantiate(E, transform.position, transform.rotation);
                            newE.transform.localScale = new Vector3(8f, 8f, 8f);
                            newE.GetComponent<EnemyScr>().SP.enabled = true;
                            newE.GetComponent<EnemyScr>().BC.enabled = true;
                            newE.GetComponent<EnemyScr>().HP = 25;
                            newE.GetComponent<EnemyScr>().speed = 10f;
                        }
                    }
                    else if (transform.localScale.x == 8f)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            GameObject newE = Instantiate(E, transform.position, transform.rotation);
                            newE.transform.localScale = new Vector3(4f, 4f, 4f);
                            newE.GetComponent<EnemyScr>().SP.enabled = true;
                            newE.GetComponent<EnemyScr>().BC.enabled = true;
                            newE.GetComponent<EnemyScr>().HP = 15;
                            newE.GetComponent<EnemyScr>().speed = 15f;
                        }
                    }
                    else if (transform.localScale.x == 4f)
                    {
                        for (int i = 0; i < 4; i++)
                        {
                            GameObject newE = Instantiate(E, transform.position, transform.rotation);
                            newE.transform.localScale = new Vector3(1f, 1f, 1f);
                            newE.GetComponent<EnemyScr>().SP.enabled = true;
                            newE.GetComponent<EnemyScr>().BC.enabled = true;
                            newE.GetComponent<EnemyScr>().HP = 1;
                            newE.GetComponent<EnemyScr>().speed = 20f;
                        }
                    }
                    if (SC.enemyCountSplit > 0)
                    {
                        Destroy(gameObject);
                    }

                }
            }
            else
            {
                if (SC.enemyCountSplit >= 1)
                {
                    lastDead = false;
                }
                if (SC.enemyCountSplit <= 0 && lastDead == true)
                {
                    if (Input.GetKeyDown(KeyCode.Space))
                    {

                        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1, LoadSceneMode.Single);
                    }
                    if (Input.GetKeyDown(KeyCode.Backspace))
                    {
                        SceneManager.LoadScene(0);
                    }
                }



            }
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {

                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
            if (Input.GetKeyDown(KeyCode.Backspace))
            {
                SceneManager.LoadScene(0);
            }
        }


    }

    private void FixedUpdate()
    {
        if (Player != null)
        {
            Vector3 dir = Vector3.Normalize((Player.transform.position - transform.position)) * speed;
            Vector2 dir2D = new Vector2(dir.x, dir.y);
            rb.AddForce(dir2D);
            reverseVel(-dir2D);
        }
    }

    void reverseVel(Vector2 vel)
    {
        if (Mathf.Abs(rb.velocity.magnitude) > speed)
        {
            rb.AddForce(-vel);
        }
    }

    override public bool death()
    {
        if (HP <= 0)
        {
            SC.enemyCountSplit -= 1;
            AudioSource B = FindObjectOfType<AudioManager>().boom;
            B.PlayOneShot(B.clip);
            Instantiate(PS, transform.position, transform.rotation);
            //HP = 50;
            SP.enabled = false;
            BC.enabled = false;
            if (SC.enemyCountSplit <= 0)
            {
                StartCoroutine(SW.StringPrintCo("BALL,WINS,BALL WINS", 0.4f));
                StartCoroutine(SW.nextLevel());
            }

            return true;
        }
        return false;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            Instantiate(collision.gameObject.GetComponent<TopDownMovement>().PS, collision.transform.position, collision.transform.rotation);
            StartCoroutine(SW.StringPrintCo("CUBE,WINS,CUBE WINS", 0.4f));
            StartCoroutine(SW.tryAgain());
            Destroy(collision.gameObject);
        }
    }
}
