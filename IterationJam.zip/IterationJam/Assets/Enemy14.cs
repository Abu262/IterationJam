﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Enemy14 : EnemyScr
{
    public GameObject bullet;
    
    bool goToWP1;
    public Transform WP1;
    public Transform WP2;
    float targetTime = 0.0f;
    float targetLimit = 0.3f;

    float targetTime2 = 0.0f;
    float targetLimit2 = 0.1f;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Player != null)
        {


            if (!dead && SP.enabled == true)
            {
                dead = death();
                targetTime += Time.deltaTime;

                if (targetTime > targetLimit)
                {
                    GameObject bulletInstance = Instantiate(bullet, transform.position, transform.rotation) as GameObject;
                    bulletInstance.GetComponent<EnemyBulletScr>().SW = SW;
                    bulletInstance.GetComponent<EnemyBulletScr>().ES = this;
                    bulletInstance.transform.rotation = Quaternion.AngleAxis(180, Vector3.forward);
                    bulletInstance.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
                    targetTime2 += Time.deltaTime;
                    if (targetTime2 > targetLimit2)
                    {
                        targetTime = 0.0f;
                        targetTime2 = 0.0f;
                        targetLimit = Random.Range(0.25f, 0.35f);
                        targetLimit2 = Random.Range(0.05f, 0.1f);
                    }
                        //fire






                }

            }
            else
            {
                if (Input.GetKeyDown(KeyCode.Space))
                {

                    SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
                }
                if (Input.GetKeyDown(KeyCode.Backspace))
                {
                    SceneManager.LoadScene(0);
                }
            }
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {

                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
            if (Input.GetKeyDown(KeyCode.Backspace))
            {
                SceneManager.LoadScene(0);
            }
        }


    }

    private void FixedUpdate()
    {
        if (Player != null)
        {
            if (goToWP1)
            {
                Vector3 dir = Vector3.Normalize((WP1.position - transform.position)) * speed;
                Vector2 dir2D = new Vector2(dir.x, dir.y);
                rb.AddForce(dir2D);
                reverseVel(-dir2D);

                if (Vector3.Distance(WP1.position, transform.position) < 0.1)
                {
                    goToWP1 = false;
                }

            }
            else
            {
                Vector3 dir = Vector3.Normalize((WP2.position - transform.position)) * speed;
                Vector2 dir2D = new Vector2(dir.x, dir.y);
                rb.AddForce(dir2D);
                reverseVel(-dir2D);
                if (Vector3.Distance(WP2.position, transform.position) < 0.1)
                {
                    goToWP1 = true;
                }

            }


        }

    }

    void reverseVel(Vector2 vel)
    {
        if (Mathf.Abs(rb.velocity.magnitude) > speed)
        {
            rb.AddForce(-vel);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            Instantiate(collision.gameObject.GetComponent<SideScrollMovement>().PS, collision.transform.position, collision.transform.rotation);
            StartCoroutine(SW.StringPrintCo("CUBE,WINS,CUBE WINS", 0.4f));
            StartCoroutine(SW.tryAgain());
            Destroy(collision.gameObject);
        }
    }
}
