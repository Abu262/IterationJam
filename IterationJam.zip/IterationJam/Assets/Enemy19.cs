﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Enemy19 : EnemyScr
{
    bool lastDead = true;
    static public int enemyCountv2 = 1;
    SceneHandler SC;
    public GameObject bullet;
    float targetTime = 0.0f;
    float currenttimer;// = Random.Range(0.5f, 1.5f);
    public List<Transform> WP = new List<Transform>();
    public bool summoner = false;
    // Start is called before the first frame update
    void Start()
    {
        currenttimer = 0.4f;
        SC = FindObjectOfType<SceneHandler>();
        Player = GameObject.FindWithTag("Player");
        SW = FindObjectOfType<ScreenWriter>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Player != null)
        {


            if (!dead)
            {
                dead = death();
                if (SC.enemyCountSplit > 0)
                {
                    targetTime += Time.deltaTime;
                    if (targetTime > currenttimer && summoner)
                    {

                        targetTime = 0.0f;

                        for (int i = 0; i < 2; i++)
                        {
                            GameObject bulletInstance = Instantiate(bullet, WP[i].position, Quaternion.Euler(new Vector3(0, 0, 0))) as GameObject;
                            SC.enemyCountSplit += 1;
                            bulletInstance.GetComponent<Enemy19>().HP = 1;
                            bulletInstance.GetComponent<Enemy19>().speed = 25;
                            bulletInstance.GetComponent<Enemy19>().summoner = false;
                            bulletInstance.transform.localScale = new Vector3(1f, 1f, 1f);
                        }
                    }
                }

                if (dead)
                {
                    SC.enemyCountSplit -= 1;
                    if (SC.enemyCountSplit > 0)
                    {
                        Destroy(gameObject);
                    }
                }
            }
            else
            {
                if (SC.enemyCountSplit >= 1)
                {
                    lastDead = false;
                }
                if (SC.enemyCountSplit <= 0 && lastDead == true)
                {
                    if (Input.GetKeyDown(KeyCode.Space))
                    {

                        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1, LoadSceneMode.Single);
                    }
                    if (Input.GetKeyDown(KeyCode.Backspace))
                    {
                        SceneManager.LoadScene(0);
                    }
                }



            }
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {

                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
            if (Input.GetKeyDown(KeyCode.Backspace))
            {
                SceneManager.LoadScene(0);
            }
        }


    }

    private void FixedUpdate()
    {
        if (Player != null)
        {
            Vector3 dir = Vector3.Normalize((Player.transform.position - transform.position)) * speed;
            Vector2 dir2D = new Vector2(dir.x, dir.y);
            rb.AddForce(dir2D);
            reverseVel(-dir2D);
        }
    }

    void reverseVel(Vector2 vel)
    {
        if (Mathf.Abs(rb.velocity.magnitude) > speed)
        {
            rb.AddForce(-vel);
        }
    }

    override public bool death()
    {
        if (HP <= 0)
        {
            AudioSource B = FindObjectOfType<AudioManager>().boom;
            B.PlayOneShot(B.clip);
            Instantiate(PS, transform.position, transform.rotation);
            //HP = 50;
            SP.enabled = false;
            BC.enabled = false;
            if (SC.enemyCountSplit <= 1)
            {
                StartCoroutine(SW.StringPrintCo("BALL,WINS,BALL WINS", 0.4f));
                StartCoroutine(SW.nextLevel());
            }

            return true;
        }
        return false;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            Instantiate(collision.gameObject.GetComponent<TopDownMovement>().PS, collision.transform.position, collision.transform.rotation);
            StartCoroutine(SW.StringPrintCo("CUBE,WINS,CUBE WINS", 0.4f));
            StartCoroutine(SW.tryAgain());
            Destroy(collision.gameObject);
        }
    }
}
