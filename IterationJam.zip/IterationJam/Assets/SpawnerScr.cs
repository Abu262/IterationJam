﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnerScr : MonoBehaviour
{
    public GameObject enemy;
    public static int MaxSpawn = 50;
    float timer = 0.0f;
    // Start is called before the first frame update
    void Start()
    {
        MaxSpawn = 50;
    }

    // Update is called once per frame
    void Update()
    {
        while (MaxSpawn > 0 && timer >= 0.15f)
        {
            timer = 0.0f;
            MaxSpawn -= 1;
            GameObject E = Instantiate(enemy, transform.position, Quaternion.Euler(new Vector3(0, 0, 0))) as GameObject;
        }
        timer += Time.deltaTime;
    }
}
