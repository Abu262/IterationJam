﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
public class MainMenu : MonoBehaviour
{

    public TextMeshProUGUI TMP;
    float timer = 0.4f;
    public string startString;

    public TextMeshProUGUI TMPIndex;
    public TextMeshProUGUI TMPL;
    public TextMeshProUGUI TMPR;
    int index = 1;
    // Start is called before the first frame update
    void Start()
    {
        TMPIndex.text = " < 1 >";
        TMP.text = "CUBE VS BALL";
        TMPL.text = "SPACEBAR: START";
        TMPR.text = "BACKSPACE: QUIT";
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {

            SceneManager.LoadScene(index);
        }
        if (Input.GetKeyDown(KeyCode.Backspace))
        {
            Application.Quit();
        }
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            index -= 1;
            if (index < 1)
            {
                index = 20;
            }
            TMPIndex.text = "< " + index.ToString() + " >";
        }
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            index += 1;
            if (index > 20)
            {
                index = 1;
            }
            TMPIndex.text = "< " + index.ToString() + " >";
        }

    }
}
