﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBulletScr : MonoBehaviour
{
    public Rigidbody2D rb;
    public float speed = 20f;
    float timer = 0.0f;
    public ParticleSystem PS;
    public ScreenWriter SW;
    public EnemyScr ES;
    // Start is called before the first frame update
    void Start()
    {
        //AudioSource C = FindObjectOfType<AudioManager>().clap;
        //C.PlayOneShot(C.clip);
        rb.velocity = transform.up * speed;
    }

    // Update is called once per frame
    void Update()
    {
        if (timer >= 10.0f)
        {
            Destroy(gameObject);
        }
        timer += Time.deltaTime;
    }

    private void FixedUpdate()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject.tag == "Wall")
        {
            Instantiate(PS, transform.position, transform.rotation);
            Destroy(gameObject);
        }
        else if (collision.gameObject.tag == "Player" && ES.SP.enabled == true)
        {
            ES.StartCoroutine(ES.SW.StringPrintCo("CUBE,WINS,CUBE WINS", 0.4f));
            ES.StartCoroutine(ES.SW.tryAgain());
            Instantiate(PS, transform.position, transform.rotation);
            if (collision.gameObject.GetComponent<TopDownMovement>())
            {
                Instantiate(collision.gameObject.GetComponent<TopDownMovement>().PS, collision.transform.position, collision.transform.rotation);
            }
            else
            {
                Instantiate(collision.gameObject.GetComponent<SideScrollMovement>().PS, collision.transform.position, collision.transform.rotation);

            }

            Destroy(collision.gameObject);
        }
    }

    private void OnDestroy()
    {

      
    }
}

