﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Enemy9 : EnemyScr
{
    bool lastDead = true;
    static public int enemyCountv3 = 50;
    // Start is called before the first frame update
    void Start()
    {
        enemyCountv3 = 50;
    }

    // Update is called once per frame
    void Update()
    {
        if (Player != null)
        {


            if (!dead)
            {
                dead = death();
                if (dead)
                {
                    enemyCountv3 -= 1;
                }
            }
            else
            {
                if (enemyCountv3 >= 1)
                {
                    lastDead = false;
                    AudioSource B = FindObjectOfType<AudioManager>().boom;
                    B.PlayOneShot(B.clip);
                    Instantiate(PS, transform.position, transform.rotation);
                    Destroy(gameObject);
                }
                if (enemyCountv3 <= 0 && lastDead == true)
                {
                    if (Input.GetKeyDown(KeyCode.Space))
                    {

                        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
                    }
                    if (Input.GetKeyDown(KeyCode.Backspace))
                    {
                        SceneManager.LoadScene(0);
                    }
                }



            }
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {

                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex, LoadSceneMode.Single);
            }
            if (Input.GetKeyDown(KeyCode.Backspace))
            {
                SceneManager.LoadScene(0);
            }
        }


    }

    private void FixedUpdate()
    {
        if (Player != null)
        {
            Vector3 dir = Vector3.Normalize((Player.transform.position - transform.position)) * speed;
            Vector2 dir2D = new Vector2(dir.x, dir.y);
            rb.AddForce(dir2D);
            reverseVel(-dir2D);
        }
    }

    void reverseVel(Vector2 vel)
    {
        if (Mathf.Abs(rb.velocity.magnitude) > speed)
        {
            rb.AddForce(-vel);
        }
    }

    override public bool death()
    {
        if (HP <= 0)
        {
            if (enemyCountv3 <= 1)
            {
                AudioSource B = FindObjectOfType<AudioManager>().boom;
                B.PlayOneShot(B.clip);
                Instantiate(PS, transform.position, transform.rotation);
                //HP = 50;
                SP.enabled = false;
                BC.enabled = false;
            
                StartCoroutine(SW.StringPrintCo("BALL,WINS,BALL WINS", 0.4f));
                StartCoroutine(SW.nextLevel());
            }

            return true;
        }
        return false;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            Instantiate(collision.gameObject.GetComponent<TopDownMovement>().PS, collision.transform.position, collision.transform.rotation);
            StartCoroutine(SW.StringPrintCo("CUBE,WINS,CUBE WINS", 0.4f));
            StartCoroutine(SW.tryAgain());
            Destroy(collision.gameObject);
        }
    }
}
