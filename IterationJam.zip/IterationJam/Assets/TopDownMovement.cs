﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TopDownMovement : MonoBehaviour
{

    public Rigidbody2D rb;
    private float speed = 30.0f;
    public ParticleSystem PS;
    public static bool quitting = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }


    private void FixedUpdate()
    {
        if (Input.GetKey(KeyCode.W))
        {
            rb.AddForce(new Vector2(0.0f, 1.0f * speed));
            reverseVel(new Vector2(0.0f, 1.0f * speed));
        }
        if (Input.GetKey(KeyCode.S))
        {
            rb.AddForce(new Vector2(0.0f, -1.0f * speed));
            reverseVel(new Vector2(0.0f, -1.0f * speed));
        }
        if (Input.GetKey(KeyCode.A))
        {
            rb.AddForce(new Vector2(-1.0f * speed, 0.0f));
            reverseVel(new Vector2(-1.0f * speed, 0.0f));
        }
        if (Input.GetKey(KeyCode.D))
        {
            rb.AddForce(new Vector2(1.0f * speed, 0.0f));
            reverseVel(new Vector2(1.0f * speed, 0.0f));
        }
        //if (Input.GetKey(KeyCode.Space))
        //{
        //    speed = 30.0f;
        //}
        //else
        //{
        //    speed = 16.0f;
        //}
    }

    void reverseVel(Vector2 vel)
    {
        if (Mathf.Abs(rb.velocity.magnitude) > speed)
        {
            rb.AddForce(-vel);
        }
    }
    void OnApplicationQuit()
    {
        quitting = true;
        foreach (ParticleSystem i in FindObjectsOfType<ParticleSystem>())
            Destroy(i);
    }

    void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.gameObject.tag == "bullet") // this string is your newly created tag
        {
            StartCoroutine(collider.GetComponent<EnemyBulletScr>().SW.StringPrintCo("BLOCK,WINS,BLOCK WINS", 0.4f));
            StartCoroutine(collider.GetComponent<EnemyBulletScr>().SW.tryAgain());
            Instantiate(collider.gameObject.GetComponent<BulletScr>().PS, collider.transform.position, collider.transform.rotation);
            Instantiate(PS, transform.position, transform.rotation);
            Destroy(collider.gameObject);
            Destroy(gameObject);
        }
    }

    private void OnDestroy()
    {
        if (FindObjectOfType<AudioManager>())
        {
            FindObjectOfType<AudioManager>().boom.Play();
        }

    }
}
