﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CanJump : MonoBehaviour
{
    public EnemyScr ES;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = ES.transform.position;
    }
    void OnTriggerEnter2D(Collider2D collider)
    {
        //if (collider.gameObject.tag == "bullet") // this string is your newly created tag
        //{
        //    StartCoroutine(collider.GetComponent<EnemyBulletScr>().SW.StringPrintCo("BLOCK,WINS,BLOCK WINS", 0.4f));
        //    StartCoroutine(collider.GetComponent<EnemyBulletScr>().SW.tryAgain());
        //    Instantiate(collider.gameObject.GetComponent<BulletScr>().PS, collider.transform.position, collider.transform.rotation);
        //    Instantiate(PS, transform.position, transform.rotation);
        //    Destroy(collider.gameObject);
        //    Destroy(gameObject);
        //}
        if (collider.gameObject.tag == "Wall") // this string is your newly created tag
        {
            ES.canJump = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Wall") // this string is your newly created tag
        {
            ES.canJump = false;
        }
    }
}
