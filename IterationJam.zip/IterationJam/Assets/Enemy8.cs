﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Enemy8 : EnemyScr
{
    bool lastDead = true;
    static public int enemyCountv2 = 4;
    // Start is called before the first frame update
    void Start()
    {
        enemyCountv2 = 4;
    }

    // Update is called once per frame
    void Update()
    {
        if (Player != null)
        {


            if (!dead)
            {
                dead = death();
                if (dead)
                {
                    enemyCountv2 -= 1;
                }
            }
            else
            {
                if (enemyCountv2 >= 1)
                {
                    lastDead = false;
                }
                if (enemyCountv2 <= 0 && lastDead == true)
                {
                    if (Input.GetKeyDown(KeyCode.Space))
                    {

                        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1, LoadSceneMode.Single);
                    }
                    if (Input.GetKeyDown(KeyCode.Backspace))
                    {
                        SceneManager.LoadScene(0);
                    }
                }



            }
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {

                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
            if (Input.GetKeyDown(KeyCode.Backspace))
            {
                SceneManager.LoadScene(0);
            }
        }


    }

    private void FixedUpdate()
    {
        if (Player != null)
        {
            Vector3 dir = Vector3.Normalize((Player.transform.position - transform.position)) * speed;
            Vector2 dir2D = new Vector2(dir.x, dir.y);
            rb.AddForce(dir2D);
            reverseVel(-dir2D);
        }
    }

    void reverseVel(Vector2 vel)
    {
        if (Mathf.Abs(rb.velocity.magnitude) > speed)
        {
            rb.AddForce(-vel);
        }
    }

    override public bool death()
    {
        if (HP <= 0)
        {
            AudioSource B = FindObjectOfType<AudioManager>().boom;
            B.PlayOneShot(B.clip);
            Instantiate(PS, transform.position, transform.rotation);
            //HP = 50;
            SP.enabled = false;
            BC.enabled = false;
            if (enemyCountv2 <= 1)
            {
                StartCoroutine(SW.StringPrintCo("BALL,WINS,BALL WINS", 0.4f));
                StartCoroutine(SW.nextLevel());
            }

            return true;
        }
        return false;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            Instantiate(collision.gameObject.GetComponent<TopDownMovement>().PS, collision.transform.position, collision.transform.rotation);
            StartCoroutine(SW.StringPrintCo("CUBE,WINS,CUBE WINS", 0.4f));
            StartCoroutine(SW.tryAgain());
            Destroy(collision.gameObject);
        }
    }
}
