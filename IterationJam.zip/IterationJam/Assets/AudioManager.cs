﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    private static AudioManager instance;
    public List<AudioSource> AC = new List<AudioSource>();
    int i = 0;
    public GameObject AM;

    public AudioSource clap;
    public AudioSource boom;
    // Start is called before the first frame update
    void Start()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(AM);
            StartCoroutine(AudioLoop());
        }
        else
        {
            Destroy(gameObject);
        }



    }

    // Update is called once per frame
    void Update()
    {
        
    }

    IEnumerator AudioLoop()
    {
        while (true)
        {
            i = Random.Range(0, 3);
            AC[i].Play();
            yield return new WaitForSeconds(AC[i].clip.length);
            yield return new WaitForSeconds(1.0f);
        }
        yield return null;
    }
}
