﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Enemy2 : EnemyScr
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Player != null)
        {


            
            //reverseVel(-dir2D);
            if (!dead)
            {
                dead = death();
            }
            else
            {
                if (Input.GetKeyDown(KeyCode.Space))
                {

                    SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
                }
                if (Input.GetKeyDown(KeyCode.Backspace))
                {
                    SceneManager.LoadScene(0);
                }
            }
        }
        else
        {
            if (Input.GetKeyDown(KeyCode.Space))
            {

                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
            if (Input.GetKeyDown(KeyCode.Backspace))
            {
                SceneManager.LoadScene(0);
            }
        }


    }
    private void FixedUpdate()
    {
        if (Player != null)
        {
            Vector3 dir = Vector3.Normalize((Player.transform.position - transform.position)) * speed;
            Vector2 dir2D = new Vector2(dir.x, dir.y);
            rb.velocity = (dir2D);
        }
    }

    void reverseVel(Vector2 vel)
    {
        if (Mathf.Abs(rb.velocity.magnitude) > speed)
        {
            rb.AddForce(-vel);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            Instantiate(collision.gameObject.GetComponent<TopDownMovement>().PS, collision.transform.position, collision.transform.rotation);
            StartCoroutine(SW.StringPrintCo("CUBE,WINS,CUBE WINS", 0.4f));
            StartCoroutine(SW.tryAgain());
            Destroy(collision.gameObject);
        }
    }
}
