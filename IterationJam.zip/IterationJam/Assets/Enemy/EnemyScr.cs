﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class EnemyScr : MonoBehaviour
{
    public int HP = 50;
    public Rigidbody2D rb;
    public float speed;
    public ParticleSystem PS;
    public BoxCollider2D BC;
    public SpriteRenderer SP;
    public ScreenWriter SW;
    public GameObject Player;
    protected bool dead = false;
    [HideInInspector]
    public bool canJump = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
    }

    virtual public bool death()
    {
        if (HP <= 0)
        {
            AudioSource B = FindObjectOfType<AudioManager>().boom;
            B.PlayOneShot(B.clip);
            //PS.Play();
            //HP = 50;
            SP.enabled = false;
            BC.enabled = false;
            Instantiate(PS, transform.position, transform.rotation);
            StartCoroutine(SW.StringPrintCo("BALL,WINS,BALL WINS", 0.4f));
            StartCoroutine(SW.nextLevel());
            return true;
        }
        return false;
    }

    void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.gameObject.tag == "bullet") // this string is your newly created tag
        {
            HP -= 1;
            Instantiate(collider.gameObject.GetComponent<BulletScr>().PS, collider.transform.position, collider.transform.rotation);
            Destroy(collider.gameObject);
        }
    }
}
